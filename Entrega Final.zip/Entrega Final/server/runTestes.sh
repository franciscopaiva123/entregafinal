# Franisco Paiva 96737
# Joao Rebolo 96748

#!/bin/bash

#Reads arguments from terminal 

if [ $# != 3 ];
then
	#Error print
	echo $inputdir Argument Error.
	exit
fi

inputdir=${1}
outputdir=${2} 
maxthreads=${3}


#Checks if input directory exists
if [ ! -d $inputdir ];
then
	#Error print
	echo $inputdir Non existant.
	exit
fi

#Checks if output directory exists
if [ ! -d $outputdir ];
then
	#Error print
	echo $outputdir Non existant.
	exit
fi

#Checks if maxthreads >= 1
if [ $maxthreads \> $0 ];
then
	#Error print
	echo maxthreas = $maxthreads Number of threads is below 1.
	exit
fi

#Goes trough all input files
for input in $inputdir/*.txt 
do
	
	#Runs each number of threads from one to maxthreads
	for i in $(seq 1 $maxthreads) 
	do 
		echo InputFile=${input##*/} NumThreads=$i;
		./tecnicofs $input $outputdir/$(basename ${input%.txt})-${i}.txt $i | tail -n 1 #Prints runtime	
	done
	echo 
done
