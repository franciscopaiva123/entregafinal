#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>
#include "state.h"
#include "../tecnicofs-api-constants.h"
 
#define WRITE  "write"
#define READ   "read"


inode_t inode_table[INODE_TABLE_SIZE];

pthread_mutex_t mutex;
pthread_rwlock_t lock;

/* Function that initializes the RWLOCK */
void init_rwlock(int inumber){
    int err;
    /*starts rwlock*/
    err=pthread_rwlock_init(&inode_table[inumber].rwlock, NULL); 
    if(err != 0){
        printf("rwlock init failed\n");
        exit(EXIT_FAILURE);
    }
} 

/* Function that destroys the initialization of RWLOCK*/
void destroy_rwlock(int inumber){
    int err;
    /*destroys rwlock*/
    err = pthread_rwlock_destroy(&inode_table[inumber].rwlock);
    if(err != 0){
        fprintf(stderr,"Destruction failed (RWLOCK)\n");
        exit(EXIT_FAILURE);
    }
}

void init_global(){
    /*starts mutex*/
    if (pthread_rwlock_init(&lock, NULL) != 0){
        printf("\n global rwlock init failed\n");
        exit(EXIT_FAILURE);
    } 
}

void destroy_global(){
    int err;
    /*destroys mutex*/
    err = pthread_rwlock_destroy(&lock);
    if(err != 0){
        fprintf(stderr,"Destruction failed (GLOABL RWLOCK)\n");
        exit(EXIT_FAILURE);
    }
}

/* Function that performs rwlocks given the option */
void rw_lock(char* stratmode,int inumber){
    int err;
    if((strcmp(stratmode,WRITE)==0)){ 
        err=pthread_rwlock_wrlock(&inode_table[inumber].rwlock);
        if(err != 0){
            fprintf(stderr,"Lock failed(RWLOCK)(WRITE)\n");
            exit(EXIT_FAILURE);
        } 
        return;
    }
    if((strcmp(stratmode,READ)==0)){
        err = pthread_rwlock_rdlock(&inode_table[inumber].rwlock);
        if(err != 0){
            printf("inumber locked is : %d\n",inumber );
            fprintf(stderr,"Lock failed(RWLOCK)(READ)\n");
            exit(EXIT_FAILURE);
        }
        return;
    }
}

/* Function that performs unlocks*/
void rw_unlock(int inumber){
    int err;
    /*Unlocks Rwlocks*/
        err=pthread_rwlock_unlock(&inode_table[inumber].rwlock);
        if(err != 0){
            fprintf(stderr,"Unlock failed (RWLOCK)\n");
            exit(EXIT_FAILURE);
        }
}


/* Function that performs the global mutex locks given the strategy*/
void lock_global(char* stratmode){
    int err;
    if((strcmp(stratmode,WRITE)==0)){ 
        err=pthread_rwlock_wrlock(&lock);
        if(err != 0){
            fprintf(stderr,"Lock failed(RWLOCK)(WRITE)(GLOBAL)\n");
            exit(EXIT_FAILURE);
        } 
        return;
    }
    if((strcmp(stratmode,READ)==0)){
        err = pthread_rwlock_rdlock(&lock);
        if(err != 0){
            fprintf(stderr,"Lock failed(RWLOCK)(READ)(GLOBAL)\n");
            exit(EXIT_FAILURE);
        }
        return;
    }
}

/* Unlocks global MUTEX */
void unlock_global(){
    int err;
    /*Unlocks Rwlocks*/
        err=pthread_rwlock_unlock(&lock);
        if(err != 0){
            fprintf(stderr,"Unlock failed (RWLOCK)\n");
            exit(EXIT_FAILURE);
        }
}

