#ifndef THREADPROCESS_H
#define THREADPROCESS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <pthread.h>
#include "state.h"
#include "../tecnicofs-api-constants.h"


#define MUTEX "mutex"
#define RWLOCK "rwlock"
#define WRITE "write"
#define READ "read"

pthread_mutex_t mutex;
pthread_rwlock_t lock;


void init_rwlock(int inumber);
void destroy_rwlock(int inumber);
void init_global();
void destroy_global();
void rw_lock(char* stratmode,int inumber);
void rw_unlock(int inumber);
void lock_global(char* stratmode);
void unlock_global();
#endif
